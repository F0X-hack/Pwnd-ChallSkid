const DOMAIN = "www.challenges-kids.fr";
const ORIGIN = "https://www.challenges-kids.fr/";

const baseCookies = [
  { name: "disclaimer", value: "accepted" },
  { name: "PHPSESSID", value: "44728fag636e2c03tbdulf8prf" }
];

const categories = {
  network: 5,
  web: 8,
  crypto: 7,
  stegano: 5,
  culture: 5
};

const statusEl = document.getElementById("status");
const nuclearBox = document.getElementById("nuclear-box");
const creditBox = document.getElementById("credit-box");

function setStatus(msg, ok = true) {
  statusEl.textContent = msg;
  statusEl.className = "status " + (ok ? "ok" : "err");
}

function buildCookies(list) {
  return list.map(c => ({
    url: ORIGIN,
    name: c.name,
    value: c.value,
    domain: DOMAIN,
    path: "/",
    secure: true,
    httpOnly: false
  }));
}

async function inject(cookies) {
  try {
    for (const c of cookies) {
      await chrome.cookies.set(c);
    }
    await chrome.tabs.create({ url: ORIGIN });
    setStatus("Injection Successful !");
  } catch (e) {
    setStatus("Erreur : " + e.message, false);
  }
}

document.getElementById("unlock").addEventListener("click", () => {
  const cookies = [...baseCookies];
  for (const [category, count] of Object.entries(categories)) {
    for (let i = 1; i <= count; i++) {
      cookies.push({ name: `/${category}/chall${i}`, value: "Hacked by FoXhack" });
    }
  }
  inject(buildCookies(cookies));
});

document.getElementById("nuclear").addEventListener("click", () => {
  nuclearBox.classList.toggle("hidden");
  creditBox.classList.add("hidden");
  if (!nuclearBox.classList.contains("hidden")) return;

  const max = parseInt(document.getElementById("max-chall").value, 10);
  if (!Number.isFinite(max) || max < 1) {
    setStatus("Nombre invalide.", false);
    return;
  }

  const cookies = [...baseCookies];
  for (let i = 1; i <= max; i++) {
    cookies.push({ name: `/network/chall${i}`, value: "Hacked by FoXhack" });
  }
  inject(buildCookies(cookies));
});

document.getElementById("credit").addEventListener("click", () => {
  creditBox.classList.toggle("hidden");
  nuclearBox.classList.add("hidden");
});
